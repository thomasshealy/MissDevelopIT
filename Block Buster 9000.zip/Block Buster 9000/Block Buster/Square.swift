//
//  Square.swift
//  Block Buster
//
//  Created by Thomas Shealy on 5/14/16.
//  Copyright © 2016 Thomas Shealy. All rights reserved.
//

import Foundation
//square object.  Just contains two ints that correspond to location.

class Square{
    
    var height: Int
    var width: Int
    
    init(height:Int, width:Int){
        self.height = height
        self.width = width
    }
}
